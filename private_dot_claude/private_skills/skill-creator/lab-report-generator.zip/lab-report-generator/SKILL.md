---
name: lab-report-generator
description: Generate comprehensive test report package from lab notebook. Creates structured directory with report documents, data, results, and reference materials. Use when user requests creating test report, lab report, or experimental report from lab notebook.
allowed-tools: AskUserQuestion, Bash, Read, Write, Glob, mcp__serena__list_dir, mcp__serena__find_file, mcp__serena__get_symbols_overview
---

# Lab Report Generator

This skill generates a structured test report package from lab notebook files following Logomix's documentation standards.

## Overview

Creates a standardized directory structure under `_LabReports/` containing:
- Test report documentation (PDF only, exported via Obsidian)
- Data files (moved from original location)
- Results files (moved from original location)
- Reference materials (moved from original location)
- File inventory (markdown)
- Summary document (markdown, convertible to docx)

**Important**: Original lab notebook (markdown) remains in its original location and is NOT copied to _LabReports/.

## Directory Structure

```
_LabReports/
└── XX-NNNN-{実験タイトル}/
    ├── ファイル一覧.md
    ├── Summary.md
    ├── 1_試験報告書/
    │   └── {ラボノート}.pdf (via Obsidian export)
    ├── 2_データ/
    │   └── (user provided files)
    ├── 3_結果/
    │   └── (user provided files)
    └── 4_資料/
        └── (optional user provided files)
```

## Workflow

### Step 1: Gather Information

Ask user for required information if not provided:

1. **Experiment ID** (format: `XX-NNNN-{実験タイトル}`)
   - XX: Project code (2 characters)
   - NNNN: Sequential number (4 digits)
   - 実験タイトル: Descriptive title
   - Example: `CN-0001-iPS細胞分化実験`

2. **Lab Notebook Path**
   - Full path to the lab notebook markdown file
   - Example: `0_LabNotebook/AI/20250124_experiment_analysis.md`

3. **Data and Results Files**
   - List of files to be organized (mentioned in conversation context)
   - Files can be .pptx, .docx, or other formats
   - Categorize into: データ (data), 結果 (results), 資料 (reference materials)

Use AskUserQuestion tool to collect missing information:

```
Question 1: "実験番号を指定してください（形式: XX-NNNN-{実験タイトル}）"
Question 2: "対象のラボノートファイルのパスを指定してください"
Question 3: "整理するファイルをカテゴリごとに教えてください：
- データファイル（2_データ/）
- 結果ファイル（3_結果/）
- 資料ファイル（4_資料/）※任意"
```

### Step 2: Create Directory Structure

Create the following directories under `_LabReports/`:

```bash
mkdir -p "_LabReports/{実験番号}/1_試験報告書"
mkdir -p "_LabReports/{実験番号}/2_データ"
mkdir -p "_LabReports/{実験番号}/3_結果"
mkdir -p "_LabReports/{実験番号}/4_資料"
```

### Step 3: Organize Files

1. **Keep lab notebook** in its original location (do NOT copy to 1_試験報告書/)
   - The lab notebook will remain in the original location (e.g., random/, 0_LabNotebook/, etc.)
   - Only PDF export will be saved to 1_試験報告書/ (see Step 7)

2. **Move data files** to `2_データ/` (if provided)

3. **Move result files** to `3_結果/` (if provided)

4. **Move reference files** to `4_資料/` (if provided)

### Step 4: Generate File Inventory

Create `ファイル一覧.md` at root of experiment directory using the template:
- List all files in each subdirectory
- Include file descriptions based on conversation context
- Follow template in `templates/file_list_template.md`

### Step 5: Generate Summary Document

Create `Summary.md` at root of experiment directory:
- Extract key information from lab notebook (expects template format with 4 summary callouts)
- Parse Background from `[!Todo] Background` callout
- Parse Purpose from `[!Works] Purpose` callout
- Parse Results from `[!Done] Results Summary` callout
- Parse Key Points from `[!Important] Key Points` callout
- Summarize individual experiments from standard heading sections
- Follow template in `templates/summary_template.md`

Then inform user:
```
Summary.mdを作成しました。pandocを使用してdocxに変換できます：
pandoc Summary.md -o Summary.docx
```

### Step 6: Completion Report

Report to user:
- Directory structure created
- Files organized
- Generated documents (ファイル一覧.md, Summary.md)
- Next steps (docx conversion if needed)

### Step 7: PDF Export via Obsidian

Export lab notebook as PDF using Obsidian's renderer (this is the primary report document):

1. **Run obsidian-pdf-export.sh script** (use original lab notebook path):
   ```bash
   /Users/oodakemac/.claude/skills/lab-report-generator/scripts/obsidian-pdf-export.sh "{元のラボノートパス}"
   ```
   Example: `/Users/oodakemac/.claude/skills/lab-report-generator/scripts/obsidian-pdf-export.sh "random/20251024_experiment.md"`

2. **Inform user** - IMPORTANT instructions:
   - Obsidian will open with PDF export dialog
   - **MUST save to: `_LabReports/` directory (root level)**
   - Filename: Same as markdown file but with .pdf extension
   - Example: `20251024_experiment.pdf`
   - This preserves Obsidian's beautiful rendering including colored callouts

3. **Wait for user confirmation** that PDF has been saved

4. **Check for exported PDF** in `_LabReports/` root:
   ```bash
   find _LabReports -maxdepth 1 -name "*.pdf" -type f
   ```

5. **Move PDF to correct location**:
   ```bash
   mv "_LabReports/{ラボノート名}.pdf" "_LabReports/{実験番号}/1_試験報告書/"
   ```

6. **Update ファイル一覧.md** - Add PDF entry in 1_試験報告書/ section:
   - Filename: {ラボノート名}.pdf
   - Description: ラボノートのPDF版。Obsidian PDFエクスポート機能により生成。色付きcallout、表、強調表示を含む美しいレンダリング
   - Date: Current date

**Note**: This step uses obsidian-pdf-export.sh script which requires:
- Obsidian to be installed
- Advanced URI plugin to be installed in Obsidian
- Script location: `scripts/obsidian-pdf-export.sh` (bundled with this skill)

## Important Notes

1. **Always ask for missing information** - Never assume experiment ID or file paths
2. **Keep lab notebook in original location** - Do NOT copy .md file to _LabReports/
3. **Move data/result/reference files** to organize them into the report package
4. **Create empty directories** even if no files provided (especially 4_資料/)
5. **Follow Japanese naming conventions** for directories and generated documents
6. **Expect template-compliant lab notebooks** - Lab notebooks should follow the 4-callout structure: `[!Todo] Background` → `[!Works] Purpose` → `[!Done] Results Summary` → `[!Important] Key Points` followed by experimental sections
7. **Extract meaningful content** from lab notebook when generating Summary (parse callouts and heading sections)
8. **List files with context** in file inventory, not just filenames
9. **PDF-only in 1_試験報告書/** - CRITICAL:
   - Only PDF files should be in 1_試験報告書/
   - Do NOT save .md or .docx files to 1_試験報告書/
   - Instruct user to save PDF to `_LabReports/` root directory
   - Always check `_LabReports/` root for exported PDFs with `find` command
   - Move PDF to `1_試験報告書/` subdirectory after user confirms export
   - Update `ファイル一覧.md` with PDF entry only
   - Never assume PDF location - always search and verify

## Error Handling

- If lab notebook path is invalid, ask user to verify
- If experiment ID format is incorrect, prompt user with format example
- If _LabReports/ directory doesn't exist, create it
- If target directory already exists, warn user and ask for confirmation before overwriting

## Examples

### Example 1: Basic Usage

User: "このラボノートから試験報告書を作成してください"

Assistant actions:
1. Ask for experiment ID
2. Ask for lab notebook path
3. Ask for files to organize
4. Create directory structure
5. Move data/result files (keep lab notebook in original location)
6. Generate ファイル一覧.md and Summary.md
7. Report completion
8. Export lab notebook as PDF via Obsidian and move to 1_試験報告書/

### Example 2: With Context

User: "CN-0001-iPS分化実験の報告書を作りたい。ラボノートは0_LabNotebook/Pancreas/20250124_differentiation.mdです。データとして analysis.pptx と results.docx があります。"

Assistant actions:
1. Experiment ID: CN-0001-iPS分化実験 ✓
2. Lab notebook: 0_LabNotebook/Pancreas/20250124_differentiation.md ✓
3. Files identified: analysis.pptx (データ), results.docx (結果) ✓
4. Proceed with directory creation
5. Move data/result files (keep lab notebook at 0_LabNotebook/Pancreas/)
6. Generate ファイル一覧.md and Summary.md
7. Report completion
8. Export PDF from 0_LabNotebook/Pancreas/20250124_differentiation.md and move to 1_試験報告書/
