---
cdate: YYYY-MM-DD
mdate: YYYY-MM-DD
tags: [meeting, meeting-type]
draft: false
meetingType: "general|bizdev|pl|udc|cmc|research|recruiting|vendor"
attendees: ["[[PersonName]]"]
---

# YYYYMMDD_meeting-title

日時: YYYY-MM-DD

Lx: [[PersonName1]], [[PersonName2]]
Partner: [[CompanyName/PersonName]]

## 議事

### Topic 1
- Discussion points
- Key decisions

### Topic 2
- Additional discussions

## Action Items

- [ ] Task 1 - Owner: [[PersonName]] - Due: YYYY-MM-DD
- [ ] Task 2 - Owner: [[PersonName]] - Due: YYYY-MM-DD

## Next Steps

- Follow-up items

---

> [!Info]
> Additional notes or context
