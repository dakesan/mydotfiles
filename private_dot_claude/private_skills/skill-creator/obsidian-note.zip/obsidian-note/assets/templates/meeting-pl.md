---
cdate: YYYY-MM-DD
mdate: YYYY-MM-DD
tags: [meeting, management]
draft: false
meetingType: "pl"
attendees: ["[[OdakeHiro]]"]
---

# YYYYMMDD_PL-meeting

日時: YYYY-MM-DD

参加者:
- Logomix: [[OdakeHiro]]
- Partner: [[CompanyName/PersonName]]

## アジェンダ

### 1. 前回からの進捗

### 2. 各プロジェクトレビュー

#### [[Project Alpha]]
- 進捗:
- 課題:
- 次のマイルストーン:

#### [[Project Beta]]
- 進捗:
- 課題:
- 次のマイルストーン:

### 3. リソース配分

### 4. 戦略的議論

### 5. 意思決定事項

## 決定事項

| 項目 | 決定内容 | 実行責任者 |
|------|----------|------------|
| | | [[PersonName]] |

## Action Items

| タスク | 担当者 | 期限 | 優先度 |
|--------|--------|------|--------|
| | [[PersonName]] | YYYY-MM-DD | High/Medium/Low |

## 次回会議予定
- 日時: YYYY-MM-DD
- 主要議題:

## メモ

---

> [!Info]
> 追加情報やメモ
