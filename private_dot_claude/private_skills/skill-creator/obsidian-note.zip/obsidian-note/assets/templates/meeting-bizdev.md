---
cdate: YYYY-MM-DD
mdate: YYYY-MM-DD
tags: [meeting, bizdev]
draft: false
meetingType: "bizdev"
attendees: ["[[OdakeHiro]]"]
---

# YYYYMMDD_weekly-bizdev

日時: YYYY-MM-DD

Lx: [[OdakeHiro]]

## 議事

### Topic 1

- Discussion points

## Action Items

- [ ] [[PersonName]]: Task description - Due: YYYY-MM-DD

---

> [!Info]
> 追加情報やメモ
