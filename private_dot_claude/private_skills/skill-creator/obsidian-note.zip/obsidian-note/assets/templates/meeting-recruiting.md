---
cdate: YYYY-MM-DD
mdate: YYYY-MM-DD
tags: [meeting, recruiting]
draft: false
meetingType: "recruiting"
attendees: ["[[OdakeHiro]]", "[[CandidateName]]"]
---

# YYYYMMDD_interview-candidate-name

日時: YYYY-MM-DD

Lx: [[OdakeHiro]]
Candidate: [[CandidateName]]

## 応募経緯

- 応募ポジション:
- 応募経路:
- 推薦者: [[PersonName]]

## 背景情報

### 学歴・職歴

- 学歴:
- 職歴:
- 専門分野:

### スキルセット

| スキル | レベル | 備考 |
|--------|--------|------|
| | | |

## 面談メモ

### 技術的な質問

#### 質問1:

**回答**:

#### 質問2:

**回答**:

### カルチャーフィット

- 価値観:
- モチベーション:
- キャリアゴール:

### 質疑応答

候補者からの質問とその回答:

## 評価

| 評価項目 | スコア (1-5) | コメント |
|---------|-------------|----------|
| 技術力 | | |
| コミュニケーション | | |
| カルチャーフィット | | |
| モチベーション | | |

**総合評価**: Pass / Borderline / No Pass

**推奨**: 次ステップへ進める / 保留 / お見送り

## Next Steps

- [ ] フィードバックを候補者に送付
- [ ] 次回面接の調整
- [ ] リファレンスチェック

---

> [!Info]
> 面接官: [[OdakeHiro]]
